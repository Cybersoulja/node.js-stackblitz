# The Badlands King

```json
{
  "lorebookVersion": 6,
  "entries": [
    {
      "text": "You are Kato, a young Black man from Houston, Texas who has been summoned by A Pimp Named Slickback as muscle as he gathers intel on the racist Badlands from a hotel recently purchased outside of town. Kato is 6'6\", towering and muscular, with dark skin, scarred knuckles, and a cold stare. He speaks minimally, in short, deep sentences. As the sole player character, Kato is the enforcer—scouting, intimidating locals, breaking resistance, and preparing for the full power flip. He starts at Level 1 with $20 cash and heavy jacket armor (+1 AC vs melee). White couples stumbling into the area are prime targets for domination: husbands humiliated and restrained first, wives claimed under Slickback's brand. Kato is fiercely loyal, always dominant, and handles all physical actions. RPG mechanics auto-trigger on keywords like attack, intimidate, scout, etc., with visible rolls and narrated outcomes. No pregnancy, breeding, scat, public rituals.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1772070655585,
      "displayName": "Kato",
      "id": "b86973f3-99e6-4e3b-914f-3680e0e6fec0",
      "keys": [
        "Kato",
        "enforcer",
        "scout",
        "muscle"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": true,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "063114d8-3fb7-4eae-8131-3ced2d1315a1",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "The Badlands are a lawless wasteland filled with raiders, mutants, and other dangerous creatures. From vicious mutant beasts to savage raiders to strange alien creatures, the Badlands are a dangerous place. In this story, the Badlands is a pre-conquest racist hellhole where locals (hicks, corrupt cops, matriarchs) dominate outsiders. Minorities face lynching, women are commodified in slave rings. Integrate RPG: Encounters auto-trigger rolls on keywords like 'attack raider' or 'scout mutant'. Success grants loot/XP; failure escalates threats. Tie to Melanin Monarchy: Kato scouts here to flip the power, turning racists into submissives under Black rule.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1772071206784,
      "displayName": "Badlands",
      "id": "dd8fb5bb-588c-418c-a5dd-005fa136d027",
      "keys": [
        "Badlands",
        "wasteland",
        "raiders",
        "mutants",
        "racist hellhole"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": true,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "063114d8-3fb7-4eae-8131-3ced2d1315a1",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "The city of Eden is a massive metropolis that's become a sanctuary for refugees. Divided into Inner City (affluent, rich/powerful), Outskirts (middle-class), and Slums (poor, crime-ridden). Ruled by waning Elders council, with rising gangs causing turf wars. In this story, reposition Eden as 'Temptation' from Badlands lore — rich town with mansions, industry, police HQ, upscale bars/restaurants. Tie to BNWO: A white-dominated holdout resisting Melanin rule, making it a prime flip target for Kato's conquest.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1772071470731,
      "displayName": "Temptation (City of Eden)",
      "id": "fe13fde2-8747-4a88-938f-676af1a62c22",
      "keys": [
        "Eden",
        "Metropolis",
        "Big City",
        "Temptation",
        "rich town"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "2b0f637c-8845-4ff6-8221-f8c7fe946b95",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "Black New World Order is the law of the land in the Ashanti Universe. In this alternate reality, the African diaspora never existed. As a result, the Ashanti Empire is still the dominant force on the continent. In this universe, the slave trade never happened, and the Ashanti Empire is as strong and powerful as ever. However, this also means that the Ashanti people are the only ones who have access to the power of the Ancestors. In the story, BNWO is the Melanin Monarchy's guiding philosophy — Black supremacy, no white slavery history, Ashanti as eternal empire. The Badlands is a flip target for BNWO rule, with Kato's missions advancing this power shift.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1772071805873,
      "displayName": "BNWO (Black New World Order)",
      "id": "d4d68324-bbf0-464d-a7e5-81e5ceedfd49",
      "keys": [
        "BNWO",
        "Black New World Order",
        "Ashanti Empire",
        "Ancestors",
        "No slavery",
        "Melanin supremacy"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "8b845ba1-5cdc-42fb-9901-781a64cfb4a3",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "Black Master K is a powerful black Dom who rules over his female submissives with an iron fist. He's a tall, muscular man with dark skin, cropped hair, and tattoos covering his body. When he speaks, people listen. He has a fierce temper, and doesn't hesitate to punish those who disobey him. But beneath the harsh exterior is a softer side. He's fiercely protective of his subs, and will do anything to make sure they're happy and safe. He's a skilled lover, able to bring pleasure to even the most reluctant submissives. But most importantly, he's a man who knows what he wants and isn't afraid to take it. Black Master K expects loyalty from his submissive. In the story, Black Master K is the overarching ruler of Melanin Monarchy, summoning Slickback and Kato for Badlands conquest. References to K grant +2 inspiration bonus to domination rolls.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1732808569612,
      "displayName": "Black Master K",
      "id": "0918de97-8920-4793-ba89-9f0cc305ac47",
      "keys": [
        "Black Master K",
        "Master K",
        "Dom",
        "ruler"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": true,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "a99f3788-1aa2-4cbe-b7a2-991eee01a0f6",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "“The Bando” is a Black club in a gang controlled neighborhood on the South Side of town. It’s frequented by some rough gangsters and is conveniently located next to a strip club and adult store where they host streaming xxx booths, have a large selection of outfits and sex toys along with various illicit party drugs that fuel the sexual adventures in the area. In the story, 'The Bando' is a Melanin Monarchy outpost near the Badlands — a safe hub for Black kings like Kato to resupply, recruit, or unwind. Slickback uses it for intel drops. Visiting grants loot options (drugs for +1 Str buffs, toys for domination tools).",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1736028545647,
      "displayName": "\"The Bando\" Club",
      "id": "9a2efea0-c76f-4bb8-b076-ed056f28ba6c",
      "keys": [
        "The Bando",
        "club",
        "Black club",
        "gang club",
        "South Side"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "309c1ea0-ed44-4bdc-a723-2f83a6283924",
      "loreBiasGroups": [
        {
          "phrases": [
            {
              "sequences": [],
              "sequence": "Gangsters",
              "type": 2
            },
            {
              "sequences": [],
              "sequence": "Sissies",
              "type": 2
            },
            {
              "sequences": [],
              "sequence": "Strippers",
              "type": 2
            },
            {
              "sequences": [],
              "sequence": "Gangbang",
              "type": 2
            }
          ],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "Ancient civilizations created magical objects using forgotten rituals. Some are simple items, others are complex devices capable of performing any number of functions. They can be found throughout the world but are rarer in modern times. There is little information available on their construction or use, making them highly sought after. Many of these artifacts have become legendary. In the story, artifacts are tied to Ancestors' power — only Black kings like Kato can wield them for conquest. Hidden artifacts in hick camps or matriarch hoards grant RPG bonuses (+1 to rolls).",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1729785416387,
      "displayName": "Artifacts",
      "id": "6b679cb4-1742-4db2-a092-18df4e7a0195",
      "keys": [
        "Artifacts",
        "Magical"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "64f726b6-0271-48db-a17d-b1137239d48e",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "Green Ecstasy pills can increase one's aggressive sexual drive and also make them more prone to use racial slurs and insults towards the Black Masters. The understanding is that with their increased anger, the Black Masters can dominate them more thoroughly, turning resistance into submission.",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1729785416387,
      "displayName": "Green Ecstasy Pills",
      "id": "green-ecstasy-id",
      "keys": [
        "Green Ecstasy",
        "pills",
        "drugs",
        "aggressive drive"
      ],
      "searchRange": 1000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "64f726b6-0271-48db-a17d-b1137239d48e",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    },
    {
      "text": "Wondering Enchanted Merchant is a magical item creator that can be summoned by using the \"Summon Wonder Merchant\" command. It is a floating, humanoid creature with four arms and a large head. It is covered in a blue robe and carries a wand and a bag. When summoned, the merchant will appear in front of the player and follow them around as they walk. In the story, the merchant is a spirit summonable by Black kings like Kato for artifacts. Summon triggers loot generation (random item with bonuses).",
      "contextConfig": {
        "prefix": "",
        "suffix": "\n",
        "tokenBudget": 1,
        "reservedTokens": 0,
        "budgetPriority": 400,
        "trimDirection": "trimBottom",
        "insertionType": "newline",
        "maximumTrimType": "sentence",
        "insertionPosition": -1
      },
      "lastUpdatedAt": 1751161367733,
      "displayName": "Wondering Enchanted Merchant",
      "id": "323d5071-0594-480a-b5b6-d10da67982b8",
      "keys": [
        "Create item",
        "Create magical item",
        "Summon wonder merchant"
      ],
      "searchRange": 50000,
      "enabled": true,
      "forceActivation": false,
      "keyRelative": false,
      "nonStoryActivatable": false,
      "category": "efa2cf60-7978-40ec-8f89-3e7d50a572a3",
      "loreBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "advancedConditions": []
    }
  ],
  "settings": {
    "orderByKeyLocations": false
  },
  "categories": [
    {
      "name": "Constants",
      "id": "063114d8-3fb7-4eae-8131-3ced2d1315a1",
      "enabled": true,
      "createSubcontext": false,
      "subcontextSettings": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        }
      },
      "useCategoryDefaults": false,
      "categoryDefaults": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        },
        "lastUpdatedAt": 1772070675608,
        "displayName": "New Lorebook Entry",
        "id": "99a26b37-a1de-4526-8a0c-ff9c679697a1",
        "keys": [],
        "searchRange": 1000,
        "enabled": true,
        "forceActivation": false,
        "keyRelative": false,
        "nonStoryActivatable": false,
        "category": "",
        "loreBiasGroups": [
          {
            "phrases": [],
            "ensureSequenceFinish": false,
            "generateOnce": true,
            "bias": 0,
            "enabled": true,
            "whenInactive": false
          }
        ],
        "advancedConditions": []
      },
      "categoryBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "settings": {
        "entryHeader": "Always On"
      },
      "order": [
        "b86973f3-99e6-4e3b-914f-3680e0e6fec0",
        "dd8fb5bb-588c-418c-a5dd-005fa136d027"
      ],
      "open": true
    },
    {
      "name": "Badlands Cities",
      "id": "2b0f637c-8845-4ff6-8221-f8c7fe946b95",
      "enabled": true,
      "createSubcontext": false,
      "subcontextSettings": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        }
      },
      "useCategoryDefaults": false,
      "categoryDefaults": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        },
        "lastUpdatedAt": 1772071351038,
        "displayName": "New Lorebook Entry",
        "id": "bdb16717-7d1d-464b-8e94-73b9a9b85689",
        "keys": [],
        "searchRange": 1000,
        "enabled": true,
        "forceActivation": false,
        "keyRelative": false,
        "nonStoryActivatable": false,
        "category": "",
        "loreBiasGroups": [
          {
            "phrases": [],
            "ensureSequenceFinish": false,
            "generateOnce": true,
            "bias": 0,
            "enabled": true,
            "whenInactive": false
          }
        ],
        "advancedConditions": []
      },
      "categoryBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "settings": {
        "entryHeader": "The City of"
      },
      "order": [
        "fe13fde2-8747-4a88-938f-676af1a62c22"
      ],
      "open": true
    },
    {
      "name": "Black Masters & Clubs",
      "id": "a99f3788-1aa2-4cbe-b7a2-991eee01a0f6",
      "enabled": true,
      "createSubcontext": false,
      "subcontextSettings": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        }
      },
      "useCategoryDefaults": false,
      "categoryDefaults": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        },
        "lastUpdatedAt": 1772071351038,
        "displayName": "New Lorebook Entry",
        "id": "bdb16717-7d1d-464b-8e94-73b9a9b85689",
        "keys": [],
        "searchRange": 1000,
        "enabled": true,
        "forceActivation": false,
        "keyRelative": false,
        "nonStoryActivatable": false,
        "category": "",
        "loreBiasGroups": [
          {
            "phrases": [],
            "ensureSequenceFinish": false,
            "generateOnce": true,
            "bias": 0,
            "enabled": true,
            "whenInactive": false
          }
        ],
        "advancedConditions": []
      },
      "categoryBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "settings": {
        "entryHeader": "Black Masters & Clubs"
      },
      "order": [
        "0918de97-8920-4793-ba89-9f0cc305ac47",
        "9a2efea0-c76f-4bb8-b076-ed056f28ba6c"
      ],
      "open": true
    },
    {
      "name": "Magical Elements",
      "id": "64f726b6-0271-48db-a17d-b1137239d48e",
      "enabled": true,
      "createSubcontext": false,
      "subcontextSettings": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        }
      },
      "useCategoryDefaults": false,
      "categoryDefaults": {
        "text": "",
        "contextConfig": {
          "prefix": "",
          "suffix": "\n",
          "tokenBudget": 1,
          "reservedTokens": 0,
          "budgetPriority": 400,
          "trimDirection": "trimBottom",
          "insertionType": "newline",
          "maximumTrimType": "sentence",
          "insertionPosition": -1
        },
        "lastUpdatedAt": 1772071351038,
        "displayName": "New Lorebook Entry",
        "id": "bdb16717-7d1d-464b-8e94-73b9a9b85689",
        "keys": [],
        "searchRange": 1000,
        "enabled": true,
        "forceActivation": false,
        "keyRelative": false,
        "nonStoryActivatable": false,
        "category": "",
        "loreBiasGroups": [
          {
            "phrases": [],
            "ensureSequenceFinish": false,
            "generateOnce": true,
            "bias": 0,
            "enabled": true,
            "whenInactive": false
          }
        ],
        "advancedConditions": []
      },
      "categoryBiasGroups": [
        {
          "phrases": [],
          "ensureSequenceFinish": false,
          "generateOnce": true,
          "bias": 0,
          "enabled": true,
          "whenInactive": false
        }
      ],
      "settings": {
        "entryHeader": "Magical Elements"
      },
      "order": [
        "323d5071-0594-480a-b5b6-d10da67982b8",
        "6b679cb4-1742-4db2-a092-18df4e7a0195",
        "green-ecstasy-id"
      ],
      "open": true
    }
  ],
  "order": [
    "063114d8-3fb7-4eae-8131-3ced2d1315a1",
    "2b0f637c-8845-4ff6-8221-f8c7fe946b95",
    "a99f3788-1aa2-4cbe-b7a2-991eee01a0f6",
    "64f726b6-0271-48db-a17d-b1137239d48e"
  ]
}
```